AMETHYST LOADING SCREEN PATCH — Paper 1.21.11

1. Copy assets/minecraft/textures/misc/pumpkinblur.png into your existing
   resource pack, replacing that file if it already exists.

2. Copy LoadingScreenManager.java and LoadingScreenListener.java into:
   src/main/java/pl/neobedwars/neoBedwars/

3. Register the listener in NeoBedwarsPlugin.onEnable():

getServer().getPluginManager().registerEvents(
        new LoadingScreenListener(),
        this
);

4. Before the teleport/world transition you want to cover, call:

LoadingScreenManager.show(player);

5. LoadingScreenListener automatically hides the screen when
   PlayerClientLoadedWorldEvent fires.

The manager saves the player's helmet and restores it afterwards.
