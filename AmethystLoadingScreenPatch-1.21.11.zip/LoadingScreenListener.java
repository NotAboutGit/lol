package pl.neobedwars.neoBedwars;

import io.papermc.paper.event.player.PlayerClientLoadedWorldEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public final class LoadingScreenListener implements Listener {
    @EventHandler
    public void onClientLoadedWorld(PlayerClientLoadedWorldEvent event) {
        LoadingScreenManager.hide(event.getPlayer());
    }
}
