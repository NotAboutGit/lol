package pl.neobedwars.neoBedwars;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LoadingScreenManager {
    private static final Map<UUID, ItemStack> SAVED_HELMETS = new HashMap<>();

    private LoadingScreenManager() {}

    public static void show(Player player) {
        UUID uuid = player.getUniqueId();

        if (!SAVED_HELMETS.containsKey(uuid)) {
            ItemStack helmet = player.getInventory().getHelmet();
            SAVED_HELMETS.put(uuid, helmet == null ? null : helmet.clone());
        }

        player.getInventory().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));
    }

    public static void hide(Player player) {
        UUID uuid = player.getUniqueId();

        if (!SAVED_HELMETS.containsKey(uuid)) return;

        player.getInventory().setHelmet(SAVED_HELMETS.remove(uuid));
    }
}
